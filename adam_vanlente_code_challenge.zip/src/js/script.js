/**
 * Client side JS for the app, minimized by Grunt.
 */

var someNameSpace = {

};
